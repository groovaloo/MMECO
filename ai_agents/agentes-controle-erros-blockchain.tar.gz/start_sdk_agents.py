#!/usr/bin/env python3
"""
Start SDK Agents - Script de inicialização do sistema de agentes
Ponto de entrada principal para iniciar todos os agentes SDK
"""

import argparse
import asyncio
import logging
import sys
import signal
from pathlib import Path
from typing import Dict, List, Optional

# Importar o agente unificado
sys.path.insert(0, str(Path(__file__).parent / "integration"))
from unified_agent import UnifiedAgent, AgentConfig

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def print_banner():
    """Imprime o banner do sistema."""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                    MMECO SDK AGENTS                          ║
║              Sistema de Detecção Automática                  ║
║                    de Erros de Compilação                    ║
╚══════════════════════════════════════════════════════════════╝

🚀 Sistema de agentes para detecção automática de erros
📡 Keep-alive inteligente (2 minutos)
🔍 Detecção de erros Rust/Substrate
🧠 Memória unificada de soluções
🚨 Alertas inteligentes
📚 Documentação automática
🌉 Integração DAO

"""
    print(banner)


def print_status_summary(agent):
    """Imprime resumo do status do agente."""
    status = agent.get_status()
    
    print("\n" + "="*60)
    print("📊 RESUMO DO SISTEMA")
    print("="*60)
    print(f"Status: {status['status']}")
    print(f"Uptime: {status['uptime']:.2f}s")
    print(f"Agentes: {status['agents_running']}/{status['agents_started']}")
    print(f"Alertas: {status['total_alerts']}")
    print(f"Erros: {status['total_errors']}")
    
    print("\n🔧 COMPONENTES ATIVOS:")
    for component, running in status['components'].items():
        emoji = "✅" if running else "❌"
        print(f"  {emoji} {component}")
    
    print("="*60)


async def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="MMECO SDK Agents - Sistema de detecção automática de erros",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python start_sdk_agents.py                    # Iniciar com configuração padrão
  python start_sdk_agents.py --status          # Mostrar status
  python start_sdk_agents.py --help           # Mostrar ajuda
  python start_sdk_agents.py --no-alerts      # Desativar alertas
  python start_sdk_agents.py --no-dao-bridge  # Desativar integração DAO
        """
    )
    
    # Argumentos de configuração
    parser.add_argument('--no-keep-alive', action='store_true', 
                       help='Desativar keep-alive manager')
    parser.add_argument('--no-error-detection', action='store_true',
                       help='Desativar detecção de erros')
    parser.add_argument('--no-memory', action='store_true',
                       help='Desativar memory manager')
    parser.add_argument('--no-alerts', action='store_true',
                       help='Desativar alertas')
    parser.add_argument('--no-docs', action='store_true',
                       help='Desativar documentação automática')
    parser.add_argument('--no-dao-bridge', action='store_true',
                       help='Desativar integração DAO')
    
    # Argumentos de operação
    parser.add_argument('--status', action='store_true',
                       help='Mostrar status do sistema')
    parser.add_argument('--test', action='store_true',
                       help='Testar componentes sem iniciar loop principal')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Modo verboso')
    
    args = parser.parse_args()
    
    # Configurar logging
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Imprimir banner
    print_banner()
    
    # Configurar agente
    agent_config = AgentConfig(
        enable_keep_alive=not args.no_keep_alive,
        enable_error_detection=not args.no_error_detection,
        enable_memory_management=not args.no_memory,
        enable_alerts=not args.no_alerts,
        enable_documentation=not args.no_docs,
        enable_dao_bridge=not args.no_dao_bridge
    )
    
    # Criar agente
    agent = UnifiedAgent(agent_config)
    
    # Modo status
    if args.status:
        agent.print_status()
        return 0
    
    # Modo teste
    if args.test:
        logger.info("🧪 Modo teste - Iniciando componentes para verificação...")
        
        try:
            # Testar componentes individualmente
            if agent_config.enable_keep_alive:
                logger.info("📡 Testando Keep Alive Manager...")
                # Não iniciar, apenas validar configuração
            
            if agent_config.enable_error_detection:
                logger.info("🔍 Testando Error Detector...")
                # Não iniciar, apenas validar configuração
            
            if agent_config.enable_memory_management:
                logger.info("🧠 Testando Memory Manager...")
                # Não iniciar, apenas validar configuração
            
            if agent_config.enable_alerts:
                logger.info("🚨 Testando Alert System...")
                # Não iniciar, apenas validar configuração
            
            if agent_config.enable_documentation:
                logger.info("📚 Testando Documentation Manager...")
                # Não iniciar, apenas validar configuração
            
            if agent_config.enable_dao_bridge:
                logger.info("🌉 Testando DAO Bridge...")
                # Não iniciar, apenas validar configuração
            
            logger.info("✅ Teste de componentes concluído")
            print_status_summary(agent)
            
        except Exception as e:
            logger.error(f"💥 Erro no teste: {e}")
            return 1
        
        return 0
    
    # Modo operação normal
    logger.info("🚀 Iniciando MMECO SDK Agents...")
    
    try:
        # Iniciar agente
        success = await agent.start()
        
        if success:
            logger.info("✅ Sistema iniciado com sucesso!")
            print_status_summary(agent)
            
            # Aguardar encerramento
            try:
                while agent.status == "running":
                    await asyncio.sleep(10)
                    # Verificar status periodicamente
                    if agent.status in ["error", "stopped"]:
                        break
            except KeyboardInterrupt:
                logger.info("⏹️  Recebido sinal de interrupção")
        
        else:
            logger.error("💥 Falha ao iniciar sistema")
            return 1
    
    except Exception as e:
        logger.error(f"💥 Erro inesperado: {e}")
        return 1
    
    finally:
        # Parar agente
        logger.info("🛑 Parando sistema...")
        await agent.stop()
        logger.info("✅ Sistema parado")
    
    return 0


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        logger.info("⏹️  Encerramento forçado pelo usuário")
        sys.exit(0)
    except Exception as e:
        logger.error(f"💥 Erro fatal: {e}")
        sys.exit(1)