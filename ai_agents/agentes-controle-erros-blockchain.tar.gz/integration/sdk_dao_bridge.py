"""
SDK DAO Bridge - Ponte de integração entre agentes SDK e infraestrutura DAO
Conecta os novos agentes de detecção de erros com a comunidade descentralizada
"""

import asyncio
import logging
import json
import time
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib

# Importar configurações
sys.path.insert(0, str(Path(__file__).parent.parent / "sdk_agents"))
from config import get_config, validate_config

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class BridgeStatus(Enum):
    """Status da ponte de integração."""
    DISCONNECTED = "disconnected"
    CONNECTED = "connected"
    SYNCING = "syncing"
    ERROR = "error"


@dataclass
class BridgeEvent:
    """Evento de integração entre SDK e DAO."""
    timestamp: datetime
    event_type: str
    source: str
    data: Dict[str, Any]
    priority: int = 1


class SDKDAOBridge:
    """
    Ponte de integração entre agentes SDK e infraestrutura DAO.
    Facilita a comunicação e sincronização de dados entre os sistemas.
    """
    
    def __init__(self, config=None):
        self.config = config or get_config()
        self.status = BridgeStatus.DISCONNECTED
        
        # Componentes conectados
        self.connected_agents: Dict[str, Any] = {}
        self.event_queue: List[BridgeEvent] = []
        self.callbacks: List[Callable] = []
        
        # Estatísticas de integração
        self.stats = {
            'events_processed': 0,
            'sync_operations': 0,
            'errors': 0,
            'last_sync': None,
            'connected_agents': 0
        }
        
        # Configurações de sincronização
        self.sync_config = {
            'enabled': True,
            'interval_minutes': 10,
            'batch_size': 100,
            'auto_retry': True,
            'max_retries': 3
        }
    
    def connect_agent(self, agent_name: str, agent_instance: Any):
        """Conecta um agente ao sistema de integração."""
        self.connected_agents[agent_name] = agent_instance
        self.stats['connected_agents'] = len(self.connected_agents)
        
        logger.info(f"🔗 Agente conectado: {agent_name}")
        
        # Configurar callbacks
        if hasattr(agent_instance, 'add_callback'):
            agent_instance.add_callback(self._handle_agent_event)
    
    def disconnect_agent(self, agent_name: str):
        """Desconecta um agente do sistema de integração."""
        if agent_name in self.connected_agents:
            del self.connected_agents[agent_name]
            self.stats['connected_agents'] = len(self.connected_agents)
            logger.info(f"🔌 Agente desconectado: {agent_name}")
    
    def add_callback(self, callback: Callable):
        """Adiciona callback para eventos de integração."""
        self.callbacks.append(callback)
    
    async def start_bridge(self):
        """Inicia a ponte de integração."""
        if not validate_config():
            logger.error("Configuração inválida, não é possível iniciar a ponte")
            return False
        
        logger.info("🌉 Iniciando SDK DAO Bridge")
        self.status = BridgeStatus.CONNECTED
        
        try:
            # Iniciar sincronização automática
            asyncio.create_task(self._sync_loop())
            
            # Iniciar processamento de eventos
            asyncio.create_task(self._event_processor())
            
            logger.info("✅ SDK DAO Bridge iniciado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"💥 Erro ao iniciar ponte: {e}")
            self.status = BridgeStatus.ERROR
            return False
    
    async def stop_bridge(self):
        """Para a ponte de integração."""
        logger.info("🛑 Parando SDK DAO Bridge")
        self.status = BridgeStatus.DISCONNECTED
        
        # Salvar estado
        await self._save_bridge_state()
    
    async def _sync_loop(self):
        """Loop de sincronização automática."""
        while self.status == BridgeStatus.CONNECTED:
            try:
                if self.sync_config['enabled']:
                    await self.perform_sync()
                
                # Aguardar próximo ciclo
                await asyncio.sleep(self.sync_config['interval_minutes'] * 60)
                
            except Exception as e:
                logger.error(f"💥 Erro no loop de sincronização: {e}")
                await asyncio.sleep(60)  # Esperar 1 minuto antes de tentar novamente
    
    async def perform_sync(self):
        """Realiza operação de sincronização."""
        if self.status != BridgeStatus.CONNECTED:
            return
        
        self.status = BridgeStatus.SYNCING
        self.stats['sync_operations'] += 1
        self.stats['last_sync'] = datetime.now()
        
        try:
            # Sincronizar dados dos agentes
            sync_data = await self._collect_agent_data()
            
            # Processar sincronização
            await self._process_sync(sync_data)
            
            # Notificar sobre sincronização
            await self._notify_sync_complete(sync_data)
            
            self.status = BridgeStatus.CONNECTED
            logger.info("🔄 Sincronização concluída")
            
        except Exception as e:
            logger.error(f"💥 Erro na sincronização: {e}")
            self.stats['errors'] += 1
            self.status = BridgeStatus.ERROR
    
    async def _collect_agent_data(self) -> Dict[str, Any]:
        """Coleta dados dos agentes conectados."""
        data = {
            'timestamp': datetime.now().isoformat(),
            'agents': {},
            'stats': self.stats.copy(),
            'bridge_status': self.status.value
        }
        
        for agent_name, agent in self.connected_agents.items():
            try:
                agent_data = {}
                
                # Coletar status do agente
                if hasattr(agent, 'get_status'):
                    agent_data['status'] = agent.get_status()
                
                # Coletar estatísticas
                if hasattr(agent, 'get_stats'):
                    agent_data['stats'] = agent.get_stats()
                
                # Coletar métricas específicas
                if hasattr(agent, 'get_metrics'):
                    agent_data['metrics'] = agent.get_metrics()
                
                data['agents'][agent_name] = agent_data
                
            except Exception as e:
                logger.warning(f"⚠️  Erro ao coletar dados do agente {agent_name}: {e}")
                data['agents'][agent_name] = {'error': str(e)}
        
        return data
    
    async def _process_sync(self, sync_data: Dict[str, Any]):
        """Processa dados de sincronização."""
        # Salvar dados de sincronização
        sync_file = self.config.project_root / f"sync-data-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        
        try:
            with open(sync_file, 'w', encoding='utf-8') as f:
                json.dump(sync_data, f, indent=2, default=str)
            
            # Atualizar estado da DAO
            await self._update_dao_state(sync_data)
            
            # Gerar relatório de sincronização
            await self._generate_sync_report(sync_data)
            
        except Exception as e:
            logger.error(f"💥 Erro ao processar sincronização: {e}")
            raise
    
    async def _update_dao_state(self, sync_data: Dict[str, Any]):
        """Atualiza estado da DAO com dados do SDK."""
        # Atualizar memória DAO
        dao_memory_file = self.config.project_root / "ai-agents" / "dao_memory.json"
        
        try:
            # Carregar memória existente
            dao_memory = {}
            if dao_memory_file.exists():
                with open(dao_memory_file, 'r', encoding='utf-8') as f:
                    dao_memory = json.load(f)
            
            # Atualizar com dados do SDK
            sdk_data = {
                'last_sync': sync_data['timestamp'],
                'agents_connected': list(sync_data['agents'].keys()),
                'sdk_stats': sync_data['stats'],
                'bridge_status': sync_data['bridge_status']
            }
            
            dao_memory['sdk_integration'] = sdk_data
            
            # Salvar memória atualizada
            with open(dao_memory_file, 'w', encoding='utf-8') as f:
                json.dump(dao_memory, f, indent=2, default=str)
            
            logger.debug("💾 Estado da DAO atualizado com dados do SDK")
            
        except Exception as e:
            logger.error(f"💥 Erro ao atualizar estado da DAO: {e}")
            raise
    
    async def _generate_sync_report(self, sync_data: Dict[str, Any]):
        """Gera relatório de sincronização."""
        report_file = self.config.project_root / f"sync-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.md"
        
        content = f"""# Relatório de Sincronização SDK-DAO

**Data:** {sync_data['timestamp']}
**Status:** {sync_data['bridge_status']}

## Agentes Conectados

"""
        
        for agent_name, agent_data in sync_data['agents'].items():
            content += f"- **{agent_name}**: "
            if 'status' in agent_data:
                status = agent_data['status'].get('is_running', 'unknown')
                content += f"Status: {status}"
            if 'error' in agent_data:
                content += f" Erro: {agent_data['error']}"
            content += "\n"
        
        content += f"""

## Estatísticas da Ponte

- **Operações de Sync:** {self.stats['sync_operations']}
- **Eventos Processados:** {self.stats['events_processed']}
- **Erros:** {self.stats['errors']}
- **Agentes Conectados:** {self.stats['connected_agents']}
- **Último Sync:** {self.stats['last_sync']}

## Dados Sincronizados

```json
{json.dumps(sync_data, indent=2, default=str)}
```

---
*Relatório gerado automaticamente pelo SDK DAO Bridge*
"""
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"📊 Relatório de sincronização gerado: {report_file}")
            
        except Exception as e:
            logger.error(f"💥 Erro ao gerar relatório: {e}")
    
    async def _notify_sync_complete(self, sync_data: Dict[str, Any]):
        """Notifica sobre conclusão de sincronização."""
        event = BridgeEvent(
            timestamp=datetime.now(),
            event_type="sync_complete",
            source="bridge",
            data={
                'sync_data': sync_data,
                'agents_affected': list(sync_data['agents'].keys())
            }
        )
        
        await self._handle_event(event)
    
    def _handle_agent_event(self, level: str, message: str, data: Optional[Dict] = None):
        """Handler para eventos de agentes."""
        event = BridgeEvent(
            timestamp=datetime.now(),
            event_type="agent_event",
            source="agent",
            data={
                'level': level,
                'message': message,
                'agent_data': data or {}
            }
        )
        
        self.event_queue.append(event)
    
    async def _event_processor(self):
        """Processador de eventos da ponte."""
        while self.status in [BridgeStatus.CONNECTED, BridgeStatus.SYNCING]:
            try:
                if self.event_queue:
                    event = self.event_queue.pop(0)
                    await self._handle_event(event)
                
                await asyncio.sleep(1)  # Pequeno delay
                
            except Exception as e:
                logger.error(f"💥 Erro no processador de eventos: {e}")
                await asyncio.sleep(5)
    
    async def _handle_event(self, event: BridgeEvent):
        """Processa evento da ponte."""
        self.stats['events_processed'] += 1
        
        # Chamar callbacks
        for callback in self.callbacks:
            try:
                await callback(event)
            except Exception as e:
                logger.error(f"💥 Erro no callback de evento: {e}")
        
        # Log do evento
        logger.debug(f"📨 Evento processado: {event.event_type} - {event.source}")
    
    async def _save_bridge_state(self):
        """Salva estado da ponte."""
        state_file = self.config.project_root / "bridge-state.json"
        
        state = {
            'status': self.status.value,
            'stats': self.stats,
            'connected_agents': list(self.connected_agents.keys()),
            'last_save': datetime.now().isoformat()
        }
        
        try:
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, default=str)
            
            logger.info("💾 Estado da ponte salvo")
            
        except Exception as e:
            logger.error(f"💥 Erro ao salvar estado da ponte: {e}")
    
    def get_bridge_stats(self) -> Dict:
        """Retorna estatísticas da ponte."""
        return {
            **self.stats,
            'status': self.status.value,
            'connected_agents': list(self.connected_agents.keys()),
            'queue_size': len(self.event_queue)
        }
    
    def print_bridge_status(self):
        """Imprime status da ponte."""
        stats = self.get_bridge_stats()
        
        print("\n" + "="*60)
        print("🌉 SDK DAO BRIDGE STATUS")
        print("="*60)
        print(f"Status: {stats['status']}")
        print(f"Connected Agents: {stats['connected_agents']}")
        print(f"Events Processed: {stats['events_processed']}")
        print(f"Sync Operations: {stats['sync_operations']}")
        print(f"Errors: {stats['errors']}")
        print(f"Queue Size: {stats['queue_size']}")
        print(f"Last Sync: {stats['last_sync']}")
        
        print("\n🔗 CONNECTED AGENTS:")
        for agent in stats['connected_agents']:
            print(f"  • {agent}")
        
        print("="*60)


def main():
    """Função principal para teste."""
    bridge = SDKDAOBridge()
    
    # Simular conexão de agentes
    class MockAgent:
        def get_status(self):
            return {'is_running': True, 'test': True}
        
        def get_stats(self):
            return {'test_stats': 42}
    
    mock_agent = MockAgent()
    bridge.connect_agent("test_agent", mock_agent)
    
    # Iniciar ponte
    asyncio.run(bridge.start_bridge())
    bridge.print_bridge_status()
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())