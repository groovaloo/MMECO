"""
Unified Agent - Agente unificado que orquestra todos os agentes SDK
Ponto de entrada principal para o sistema de detecção automática de erros
"""

import asyncio
import logging
import signal
import sys
import time
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

# Importar configurações e módulos
sys.path.insert(0, str(Path(__file__).parent.parent / "sdk_agents"))
from config import get_config, validate_config
from keep_alive_manager import KeepAliveManager
from error_detector import ErrorDetector
from memory_manager import MemoryManager
from alert_system import AlertSystem
from documentation_manager import DocumentationManager

sys.path.insert(0, str(Path(__file__).parent))
from sdk_dao_bridge import SDKDAOBridge

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class AgentStatus(Enum):
    """Status do agente unificado."""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    ERROR = "error"


@dataclass
class AgentConfig:
    """Configuração do agente unificado."""
    enable_keep_alive: bool = True
    enable_error_detection: bool = True
    enable_memory_management: bool = True
    enable_alerts: bool = True
    enable_documentation: bool = True
    enable_dao_bridge: bool = True
    auto_start: bool = True
    log_level: str = "INFO"


class UnifiedAgent:
    """
    Agente unificado que orquestra todos os agentes SDK.
    Ponto de entrada principal para o sistema de detecção automática de erros.
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        self.config = config or AgentConfig()
        self.sdk_config = get_config()
        
        # Componentes
        self.keep_alive: Optional[KeepAliveManager] = None
        self.error_detector: Optional[ErrorDetector] = None
        self.memory_manager: Optional[MemoryManager] = None
        self.alert_system: Optional[AlertSystem] = None
        self.docs_manager: Optional[DocumentationManager] = None
        self.dao_bridge: Optional[SDKDAOBridge] = None
        
        # Estado
        self.status = AgentStatus.STOPPED
        self.start_time: Optional[datetime] = None
        self.tasks: List[asyncio.Task] = []
        
        # Estatísticas
        self.stats = {
            'agents_started': 0,
            'agents_running': 0,
            'total_errors': 0,
            'total_alerts': 0,
            'uptime': 0
        }
        
        # Configurar handlers de sinal
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handler para sinais de interrupção."""
        logger.info(f"Recebido sinal {signum}, encerrando agente unificado...")
        asyncio.create_task(self.stop())
    
    async def start(self):
        """Inicia o agente unificado e todos os componentes."""
        if not validate_config():
            logger.error("Configuração inválida, não é possível iniciar")
            return False
        
        logger.info("🚀 Iniciando Unified Agent")
        self.status = AgentStatus.STARTING
        self.start_time = datetime.now()
        
        try:
            # Iniciar componentes
            await self._start_components()
            
            # Iniciar loop principal
            self.status = AgentStatus.RUNNING
            await self._main_loop()
            
            return True
            
        except Exception as e:
            logger.error(f"💥 Erro ao iniciar agente unificado: {e}")
            self.status = AgentStatus.ERROR
            return False
    
    async def stop(self):
        """Para o agente unificado e todos os componentes."""
        logger.info("🛑 Parando Unified Agent")
        self.status = AgentStatus.STOPPING
        
        # Parar componentes
        await self._stop_components()
        
        # Cancelar tasks
        for task in self.tasks:
            task.cancel()
        
        # Aguardar tasks serem canceladas
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        
        self.status = AgentStatus.STOPPED
        logger.info("✅ Unified Agent parado")
    
    async def _start_components(self):
        """Inicia todos os componentes configurados."""
        logger.info("🔧 Iniciando componentes...")
        
        # Iniciar Memory Manager (dependência de outros)
        if self.config.enable_memory_management:
            self.memory_manager = MemoryManager(self.sdk_config)
            logger.info("✅ Memory Manager iniciado")
            self.stats['agents_started'] += 1
        
        # Iniciar Alert System
        if self.config.enable_alerts:
            self.alert_system = AlertSystem(self.sdk_config)
            logger.info("✅ Alert System iniciado")
            self.stats['agents_started'] += 1
        
        # Iniciar Documentation Manager
        if self.config.enable_documentation:
            self.docs_manager = DocumentationManager(self.sdk_config)
            logger.info("✅ Documentation Manager iniciado")
            self.stats['agents_started'] += 1
        
        # Iniciar Error Detector
        if self.config.enable_error_detection:
            self.error_detector = ErrorDetector(self.sdk_config)
            # Conectar callbacks
            if self.alert_system:
                self.error_detector.alerts = self.alert_system
            if self.memory_manager:
                self.error_detector.memory = self.memory_manager
            if self.docs_manager:
                self.error_detector.docs = self.docs_manager
            
            # Iniciar error detector em background
            error_detector_task = asyncio.create_task(self._start_error_detector())
            self.tasks.append(error_detector_task)
            
            logger.info("✅ Error Detector iniciado")
            self.stats['agents_started'] += 1
        
        # Iniciar Keep Alive Manager
        if self.config.enable_keep_alive:
            self.keep_alive = KeepAliveManager(self.sdk_config)
            # Conectar callbacks
            if self.alert_system:
                self.keep_alive.add_callback(self.alert_system.trigger_alert)
            
            # Iniciar keep-alive em background
            keep_alive_task = asyncio.create_task(self._start_keep_alive())
            self.tasks.append(keep_alive_task)
            
            logger.info("✅ Keep Alive Manager iniciado")
            self.stats['agents_started'] += 1
        
        # Iniciar DAO Bridge
        if self.config.enable_dao_bridge:
            self.dao_bridge = SDKDAOBridge(self.sdk_config)
            # Conectar agentes
            if self.keep_alive:
                self.dao_bridge.connect_agent("keep_alive", self.keep_alive)
            if self.error_detector:
                self.dao_bridge.connect_agent("error_detector", self.error_detector)
            if self.memory_manager:
                self.dao_bridge.connect_agent("memory_manager", self.memory_manager)
            if self.alert_system:
                self.dao_bridge.connect_agent("alert_system", self.alert_system)
            if self.docs_manager:
                self.dao_bridge.connect_agent("docs_manager", self.docs_manager)
            
            await self.dao_bridge.start_bridge()
            logger.info("✅ DAO Bridge iniciado")
            self.stats['agents_started'] += 1
        
        self.stats['agents_running'] = self.stats['agents_started']
        logger.info(f"✅ {self.stats['agents_started']} componentes iniciados")
    
    async def _stop_components(self):
        """Para todos os componentes."""
        logger.info("🔌 Parando componentes...")
        
        # Parar DAO Bridge primeiro
        if self.dao_bridge:
            await self.dao_bridge.stop_bridge()
            logger.info("✅ DAO Bridge parado")
        
        # Parar Error Detector
        if self.error_detector:
            self.error_detector.stop()
            logger.info("✅ Error Detector parado")
        
        # Parar Keep Alive Manager
        if self.keep_alive:
            self.keep_alive.stop()
            logger.info("✅ Keep Alive Manager parado")
        
        # Salvar memória
        if self.memory_manager:
            self.memory_manager.save_memory()
            logger.info("✅ Memory Manager salvo")
        
        logger.info("✅ Todos os componentes parados")
    
    async def _start_keep_alive(self):
        """Inicia o Keep Alive Manager em background."""
        try:
            if self.keep_alive:
                await self.keep_alive.start()
        except Exception as e:
            logger.error(f"💥 Erro ao iniciar Keep Alive Manager: {e}")
    
    async def _start_error_detector(self):
        """Inicia o Error Detector em background."""
        try:
            if self.error_detector:
                await self.error_detector.start()
        except Exception as e:
            logger.error(f"💥 Erro ao iniciar Error Detector: {e}")
    
    async def _main_loop(self):
        """Loop principal do agente unificado."""
        while self.status == AgentStatus.RUNNING:
            try:
                # Atualizar estatísticas
                await self._update_stats()
                
                # Verificar saúde dos componentes
                await self._health_check()
                
                # Gerar relatórios periódicos
                await self._generate_reports()
                
                # Aguardar próximo ciclo
                await asyncio.sleep(60)  # Verificar a cada minuto
                
            except Exception as e:
                logger.error(f"💥 Erro no loop principal: {e}")
                self.stats['total_errors'] += 1
                await asyncio.sleep(10)
    
    async def _update_stats(self):
        """Atualiza estatísticas do agente."""
        if self.start_time:
            self.stats['uptime'] = (datetime.now() - self.start_time).total_seconds()
        
        # Contar alertas
        if self.alert_system:
            alert_stats = self.alert_system.get_stats()
            self.stats['total_alerts'] = alert_stats.get('total_alerts', 0)
    
    async def _health_check(self):
        """Verifica saúde dos componentes."""
        health_issues = []
        
        # Verificar componentes
        if self.keep_alive and not self.keep_alive.is_running:
            health_issues.append("Keep Alive Manager parado")
        
        if self.error_detector and not self.error_detector.is_running:
            health_issues.append("Error Detector parado")
        
        if self.dao_bridge and self.dao_bridge.status != self.dao_bridge.status.CONNECTED:
            health_issues.append(f"DAO Bridge: {self.dao_bridge.status.value}")
        
        # Reportar problemas
        if health_issues:
            for issue in health_issues:
                logger.warning(f"⚠️  Problema de saúde: {issue}")
            
                if self.alert_system:
                    await self.alert_system.trigger_alert(
                        "warning",
                        f"Problemas de saúde detectados: {', '.join(health_issues)}",
                        {"health_issues": health_issues}
                    )
    
    async def _generate_reports(self):
        """Gera relatórios periódicos."""
        # Relatório a cada hora
        if self.start_time and (datetime.now() - self.start_time).seconds % 3600 == 0:
            await self.generate_hourly_report()
    
    async def generate_hourly_report(self):
        """Gera relatório horário."""
        logger.info("📊 Gerando relatório horário...")
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'status': self.status.value,
            'uptime_hours': self.stats['uptime'] / 3600 if self.stats['uptime'] else 0,
            'agents_started': self.stats['agents_started'],
            'agents_running': self.stats['agents_running'],
            'total_errors': self.stats['total_errors'],
            'total_alerts': self.stats['total_alerts']
        }
        
        # Adicionar estatísticas dos componentes
        if self.memory_manager:
            report['memory_stats'] = self.memory_manager.get_error_stats()
        
        if self.alert_system:
            report['alert_stats'] = self.alert_system.get_stats()
        
        if self.error_detector:
            report['detector_stats'] = self.error_detector.get_status()
        
        # Salvar relatório
        report_file = self.sdk_config.project_root / f"unified-agent-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, default=str)
            
            logger.info(f"📊 Relatório horário salvo: {report_file}")
            
        except Exception as e:
            logger.error(f"💥 Erro ao salvar relatório: {e}")
    
    def get_status(self) -> Dict:
        """Retorna status do agente unificado."""
        return {
            'status': self.status.value,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'uptime': self.stats['uptime'],
            'agents_started': self.stats['agents_started'],
            'agents_running': self.stats['agents_running'],
            'total_errors': self.stats['total_errors'],
            'total_alerts': self.stats['total_alerts'],
            'components': {
                'keep_alive': self.keep_alive.is_running if self.keep_alive else False,
                'error_detector': self.error_detector.is_running if self.error_detector else False,
                'memory_manager': self.memory_manager is not None,
                'alert_system': self.alert_system is not None,
                'docs_manager': self.docs_manager is not None,
                'dao_bridge': self.dao_bridge.status.value if self.dao_bridge else 'disconnected'
            }
        }
    
    def print_status(self):
        """Imprime status do agente unificado."""
        status = self.get_status()
        
        print("\n" + "="*60)
        print("🤖 UNIFIED AGENT STATUS")
        print("="*60)
        print(f"Status: {status['status']}")
        print(f"Start Time: {status['start_time']}")
        print(f"Uptime: {status['uptime']:.2f}s")
        print(f"Agents Started: {status['agents_started']}")
        print(f"Agents Running: {status['agents_running']}")
        print(f"Total Errors: {status['total_errors']}")
        print(f"Total Alerts: {status['total_alerts']}")
        
        print("\n🔧 COMPONENTS:")
        for component, running in status['components'].items():
            status_emoji = "✅" if running else "❌"
            print(f"  {status_emoji} {component}: {'Running' if running else 'Stopped'}")
        
        print("="*60)
    
    def print_help(self):
        """Imprime ajuda do agente unificado."""
        print("\n" + "="*60)
        print("🤖 UNIFIED AGENT HELP")
        print("="*60)
        print("Comandos disponíveis:")
        print("  start     - Iniciar agente unificado")
        print("  stop      - Parar agente unificado")
        print("  status    - Mostrar status")
        print("  help      - Mostrar esta ajuda")
        print("\nConfigurações:")
        print(f"  Keep Alive: {'✅' if self.config.enable_keep_alive else '❌'}")
        print(f"  Error Detection: {'✅' if self.config.enable_error_detection else '❌'}")
        print(f"  Memory Management: {'✅' if self.config.enable_memory_management else '❌'}")
        print(f"  Alerts: {'✅' if self.config.enable_alerts else '❌'}")
        print(f"  Documentation: {'✅' if self.config.enable_documentation else '❌'}")
        print(f"  DAO Bridge: {'✅' if self.config.enable_dao_bridge else '❌'}")
        print("="*60)


def main():
    """Função principal para execução standalone."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Unified Agent - Sistema de detecção automática de erros")
    parser.add_argument('--config', help='Arquivo de configuração')
    parser.add_argument('--no-keep-alive', action='store_true', help='Desativar keep-alive')
    parser.add_argument('--no-error-detection', action='store_true', help='Desativar detecção de erros')
    parser.add_argument('--no-memory', action='store_true', help='Desativar memory manager')
    parser.add_argument('--no-alerts', action='store_true', help='Desativar alertas')
    parser.add_argument('--no-docs', action='store_true', help='Desativar documentação')
    parser.add_argument('--no-dao-bridge', action='store_true', help='Desativar DAO bridge')
    parser.add_argument('--status', action='store_true', help='Mostrar status')
    parser.add_argument('--help', action='store_true', help='Mostrar ajuda')
    
    args = parser.parse_args()
    
    # Configurar agente
    agent_config = AgentConfig(
        enable_keep_alive=not args.no_keep_alive,
        enable_error_detection=not args.no_error_detection,
        enable_memory_management=not args.no_memory,
        enable_alerts=not args.no_alerts,
        enable_documentation=not args.no_docs,
        enable_dao_bridge=not args.no_dao_bridge
    )
    
    agent = UnifiedAgent(agent_config)
    
    if args.status:
        agent.print_status()
        return 0
    
    if args.help:
        agent.print_help()
        return 0
    
    try:
        # Iniciar agente
        asyncio.run(agent.start())
    except KeyboardInterrupt:
        logger.info("Encerramento solicitado pelo usuário")
    finally:
        asyncio.run(agent.stop())
    
    return 0


if __name__ == "__main__":
    sys.exit(main())