"""
Error Detector - Sistema de detecção automática de erros de compilação
Monitora builds, analisa erros e gera relatórios inteligentes
"""

import asyncio
import subprocess
import logging
import re
import json
import time
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from collections import defaultdict
import hashlib

# Importar configurações e módulos existentes
sys.path.insert(0, str(Path(__file__).parent))
from config import get_config, validate_config
from memory_manager import MemoryManager
from documentation_manager import DocumentationManager
from alert_system import AlertSystem

# Importar módulos legados
sys.path.insert(0, str(Path(__file__).parent.parent))
from rust_error_patterns import (
    get_solution_for_error, 
    format_solution_message,
    identify_error_category,
    parse_cargo_error
)
from blockchain_memory import get_blockchain_memory

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class ErrorInfo:
    """Informação detalhada sobre um erro."""
    code: Optional[str]
    message: str
    file: Optional[str]
    line: Optional[int]
    categories: List[str]
    solution: Optional[str]
    from_memory: bool
    confidence: float
    timestamp: datetime
    context: str = ""
    hints: List[str] = None
    
    def __post_init__(self):
        if self.hints is None:
            self.hints = []


@dataclass
class BuildResult:
    """Resultado de um build."""
    success: bool
    errors: List[ErrorInfo]
    warnings: List[str]
    build_time: float
    timestamp: datetime
    output_preview: str


class ErrorDetector:
    """
    Sistema de detecção automática de erros de compilação.
    Monitora builds, analisa erros e gera relatórios.
    """
    
    def __init__(self, config=None):
        self.config = config or get_config()
        self.memory = MemoryManager()
        self.docs = DocumentationManager()
        self.alerts = AlertSystem()
        
        # Estado interno
        self.is_running = False
        self.last_build_time = None
        self.error_history: Dict[str, List[ErrorInfo]] = defaultdict(list)
        self.daily_stats = defaultdict(int)
        
        # Estatísticas
        self.total_builds = 0
        self.total_errors = 0
        self.new_errors_count = 0
        self.known_errors_count = 0
        
        # Configurar alertas
        self.alerts.add_callback(self._handle_alert)
    
    async def start(self):
        """Inicia o detector de erros."""
        if not validate_config():
            logger.error("Configuração inválida, não é possível iniciar")
            return False
        
        logger.info("🔍 Iniciando Error Detector")
        logger.info(f"Monitorando: {self.config.blockchain_core}")
        logger.info(f"Intervalo: {self.config.error_monitoring['build_check_interval']}s")
        
        self.is_running = True
        
        # Iniciar loop principal
        try:
            await self._main_loop()
        except KeyboardInterrupt:
            logger.info("Encerramento solicitado pelo usuário")
        finally:
            await self.stop()
        
        return True
    
    def start_sync(self):
        """Versão síncrona para execução standalone."""
        try:
            return asyncio.run(self.start())
        except KeyboardInterrupt:
            logger.info("Encerramento solicitado pelo usuário")
            return False
    
    def stop(self):
        """Para o detector de erros."""
        logger.info("🛑 Parando Error Detector")
        self.is_running = False
        asyncio.run(self._generate_daily_report())
    
    async def _main_loop(self):
        """Loop principal do detector."""
        while self.is_running:
            try:
                # Executar análise de build
                result = await self._analyze_build()
                self._process_build_result(result)
                
                # Verificar necessidade de relatórios
                if self.config.error_monitoring['generate_reports']:
                    await self._check_report_generation()
                
                # Aguardar próximo ciclo
                await asyncio.sleep(self.config.error_monitoring['build_check_interval'])
                
            except Exception as e:
                logger.error(f"Erro no loop principal: {e}")
                await asyncio.sleep(10)
    
    async def _analyze_build(self) -> BuildResult:
        """Executa e analisa um build."""
        logger.info("🔨 Executando análise de build...")
        start_time = time.time()
        
        try:
            # Executar cargo build
            result = await asyncio.create_subprocess_exec(
                'cargo', 'build',
                cwd=self.config.blockchain_core,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            build_time = time.time() - start_time
            
            # Decodificar saída
            output = (stdout + stderr).decode('utf-8', errors='ignore')
            
            # Parse errors
            cargo_errors = parse_cargo_error(output)
            errors = []
            
            for error_data in cargo_errors:
                error_info = self._analyze_error(error_data)
                errors.append(error_info)
            
            # Contar warnings (linhas com warning)
            warnings = [line for line in output.split('\n') if 'warning:' in line.lower()]
            
            # Atualizar estatísticas
            self.total_builds += 1
            self.total_errors += len(errors)
            
            return BuildResult(
                success=result.returncode == 0,
                errors=errors,
                warnings=warnings,
                build_time=build_time,
                timestamp=datetime.now(),
                output_preview=output[-1000:]  # Últimos 1000 chars
            )
            
        except Exception as e:
            logger.error(f"Erro ao executar build: {e}")
            return BuildResult(
                success=False,
                errors=[],
                warnings=[],
                build_time=0,
                timestamp=datetime.now(),
                output_preview=f"Erro ao executar build: {e}"
            )
    
    def _analyze_error(self, error_data: Dict) -> ErrorInfo:
        """Analisa um erro individual."""
        # Extrair informações básicas
        error_msg = error_data.get('raw', '')
        code = error_data.get('code')
        message = error_data.get('message', '')
        file = error_data.get('file')
        line = error_data.get('line')
        hints = error_data.get('hints', [])
        
        # Identificar categorias
        categories = identify_error_category(error_msg)
        
        # Buscar solução
        solution = None
        from_memory = False
        confidence = 0.0
        
        # Primeiro tentar memória local
        memory_solution = self.memory.search_solution(error_msg)
        if memory_solution:
            solution = memory_solution['solution']
            from_memory = True
            confidence = memory_solution.get('confidence', 0.8)
        else:
            # Tentar base de conhecimento
            pattern = get_solution_for_error(error_msg)
            if pattern:
                solution = format_solution_message(pattern)
                confidence = 0.6
        
        # Contexto adicional
        context = f"Arquivo: {file}:{line}" if file and line else "Localização desconhecida"
        
        error_info = ErrorInfo(
            code=code,
            message=message,
            file=file,
            line=line,
            categories=categories,
            solution=solution,
            from_memory=from_memory,
            confidence=confidence,
            timestamp=datetime.now(),
            context=context,
            hints=hints
        )
        
        # Registrar no histórico
        error_key = self._get_error_key(error_info)
        self.error_history[error_key].append(error_info)
        
        # Atualizar contadores
        if confidence > 0.5:
            self.known_errors_count += 1
        else:
            self.new_errors_count += 1
        
        return error_info
    
    def _get_error_key(self, error: ErrorInfo) -> str:
        """Gera chave única para erro."""
        # Usar hash do erro para agrupamento
        key_data = f"{error.code or ''}_{error.message[:100]}_{error.file or ''}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def _process_build_result(self, result: BuildResult):
        """Processa resultado de build."""
        self.last_build_time = result.timestamp
        
        if result.success:
            logger.info(f"✅ Build bem sucedido! ({result.build_time:.2f}s)")
            return
        
        # Log resumo de erros
        new_errors = [e for e in result.errors if e.confidence < 0.5]
        known_errors = [e for e in result.errors if e.confidence >= 0.5]
        
        logger.warning(f"❌ Build falhou! ({result.build_time:.2f}s)")
        logger.warning(f"   Erros: {len(result.errors)} total")
        logger.warning(f"   Conhecidos: {len(known_errors)}")
        logger.warning(f"   Novos: {len(new_errors)}")
        
        # Atualizar memória
        for error in result.errors:
            self.memory.learn_error(
                error.message,
                error.solution or "",
                error.context
            )
        
        # Atualizar documentação
        if self.config.error_monitoring['auto_import_tracker']:
            self.docs.update_error_tracker(result.errors)
        
        # Verificar alertas
        if len(new_errors) >= self.config.alerts['new_error_threshold']:
            asyncio.create_task(self._trigger_new_errors_alert(new_errors))
        
        # Atualizar estatísticas diárias
        self._update_daily_stats(result)
    
    async def _trigger_new_errors_alert(self, new_errors: List[ErrorInfo]):
        """Dispara alerta para novos erros."""
        message = f"{len(new_errors)} novos erros detectados no build"
        await self.alerts.trigger_alert("warning", message, {
            'new_errors': len(new_errors),
            'errors': [asdict(e) for e in new_errors[:3]]  # Primeiros 3
        })
    
    def _update_daily_stats(self, result: BuildResult):
        """Atualiza estatísticas diárias."""
        today = datetime.now().strftime('%Y-%m-%d')
        self.daily_stats['builds'] += 1
        self.daily_stats['total_errors'] += len(result.errors)
        self.daily_stats['new_errors'] += len([e for e in result.errors if e.confidence < 0.5])
        self.daily_stats['known_errors'] += len([e for e in result.errors if e.confidence >= 0.5])
    
    async def _check_report_generation(self):
        """Verifica necessidade de gerar relatórios."""
        frequency = self.config.error_monitoring['report_frequency']
        
        if frequency == 'daily' and self._should_generate_daily_report():
            await self._generate_daily_report()
        elif frequency == 'weekly' and self._should_generate_weekly_report():
            await self._generate_weekly_report()
    
    def _should_generate_daily_report(self) -> bool:
        """Verifica se deve gerar relatório diário."""
        # Gerar relatório às 23:59
        now = datetime.now()
        return now.hour == 23 and now.minute >= 59
    
    def _should_generate_weekly_report(self) -> bool:
        """Verifica se deve gerar relatório semanal."""
        # Gerar relatório aos domingos às 23:59
        now = datetime.now()
        return now.weekday() == 6 and now.hour == 23 and now.minute >= 59
    
    async def _generate_daily_report(self):
        """Gera relatório diário de erros."""
        today = datetime.now().strftime('%Y-%m-%d')
        report = {
            'date': today,
            'stats': dict(self.daily_stats),
            'summary': {
                'total_builds': self.total_builds,
                'total_errors': self.total_errors,
                'new_errors': self.new_errors_count,
                'known_errors': self.known_errors_count,
                'success_rate': self._calculate_success_rate()
            },
            'top_errors': self._get_top_errors(),
            'trends': self._analyze_trends()
        }
        
        # Salvar relatório
        report_file = self.config.project_root / f"error-report-{today}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"📊 Relatório diário gerado: {report_file}")
        
        # Resetar estatísticas diárias
        self.daily_stats.clear()
    
    def _calculate_success_rate(self) -> float:
        """Calcula taxa de sucesso dos builds."""
        if self.total_builds == 0:
            return 0.0
        return (self.total_builds - self.total_errors) / self.total_builds * 100
    
    def _get_top_errors(self) -> List[Dict]:
        """Retorna erros mais frequentes."""
        error_counts = defaultdict(int)
        for errors in self.error_history.values():
            if errors:
                error_counts[errors[0].code or errors[0].message[:50]] += len(errors)
        
        top_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        return [{'error': error, 'count': count} for error, count in top_errors]
    
    def _analyze_trends(self) -> Dict:
        """Analisa tendências de erros."""
        # Simples análise de tendência (poderia ser mais sofisticada)
        recent_errors = []
        cutoff = datetime.now() - timedelta(hours=24)
        
        for errors in self.error_history.values():
            recent = [e for e in errors if e.timestamp > cutoff]
            if recent:
                recent_errors.extend(recent)
        
        return {
            'recent_errors_count': len(recent_errors),
            'new_errors_trend': 'increasing' if self.new_errors_count > self.known_errors_count else 'stable',
            'most_common_categories': self._get_common_categories(recent_errors)
        }
    
    def _get_common_categories(self, errors: List[ErrorInfo]) -> List[str]:
        """Retorna categorias mais comuns."""
        categories = defaultdict(int)
        for error in errors:
            for cat in error.categories:
                categories[cat] += 1
        
        return sorted(categories.keys(), key=lambda x: categories[x], reverse=True)[:5]
    
    async def _handle_alert(self, level: str, message: str, data: Optional[Dict] = None):
        """Handler para alertas."""
        logger.info(f"🚨 Alerta {level}: {message}")
        if data:
            logger.debug(f"   Dados: {data}")
    
    def get_status(self) -> Dict:
        """Retorna status atual do detector."""
        return {
            'is_running': self.is_running,
            'total_builds': self.total_builds,
            'total_errors': self.total_errors,
            'new_errors': self.new_errors_count,
            'known_errors': self.known_errors_count,
            'last_build': self.last_build_time.isoformat() if self.last_build_time else None,
            'daily_stats': dict(self.daily_stats),
            'error_history_size': len(self.error_history)
        }
    
    def print_status(self):
        """Imprime status atual."""
        status = self.get_status()
        
        print("\n" + "="*60)
        print("🔍 ERROR DETECTOR STATUS")
        print("="*60)
        print(f"Running: {'✅' if status['is_running'] else '❌'}")
        print(f"Total Builds: {status['total_builds']}")
        print(f"Total Errors: {status['total_errors']}")
        print(f"New Errors: {status['new_errors']}")
        print(f"Known Errors: {status['known_errors']}")
        print(f"Last Build: {status['last_build']}")
        print(f"Error History: {status['error_history_size']} tipos")
        
        if status['daily_stats']:
            print("\n📊 DAILY STATS:")
            for key, value in status['daily_stats'].items():
                print(f"  {key}: {value}")
        
        print("="*60)


def main():
    """Função principal para execução standalone."""
    detector = ErrorDetector()
    
    try:
        detector.start()
    except Exception as e:
        logger.error(f"Erro ao iniciar detector: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())