"""
Configurações do SDK - Sistema de agentes para detecção de erros
Configurações centralizadas para todos os agentes do SDK
"""

import os
from pathlib import Path
from typing import Dict, List, Optional


class SDKConfig:
    """Configurações centralizadas para os agentes do SDK."""
    
    def __init__(self):
        # Diretórios
        self.project_root = Path(__file__).parent.parent.parent
        self.blockchain_core = self.project_root / "blockchain-core"
        self.error_tracker_dir = self.project_root / "docs" / "internal" / "error-tracker"
        self.memory_file = self.project_root / "ai-agents" / "blockchain_errors_memory.json"
        
        # Configurações de Keep-Alive
        self.keep_alive = {
            'interval_seconds': 120,  # 2 minutos
            'endpoints': [
                'https://github.com',
                'https://api.github.com',
                'https://github.com/groovaloo/MMECO'
            ],
            'timeout': 10,
            'max_retries': 3,
            'log_file': self.project_root / 'keep-alive-python.log',
            'enabled': True
        }
        
        # Configurações de Monitoramento de Erros
        self.error_monitoring = {
            'build_check_interval': 300,  # 5 minutos
            'auto_import_tracker': True,
            'track_new_errors': True,
            'generate_reports': True,
            'report_frequency': 'daily',  # daily, weekly, monthly
            'alert_threshold': 5  # Alertar se >5 erros novos
        }
        
        # Configurações de Alertas
        self.alerts = {
            'enabled': True,
            'channels': ['log', 'file'],  # log, file, email, webhook
            'new_error_threshold': 1,
            'frequent_error_threshold': 3,
            'critical_patterns': [
                'build failed',
                'compilation error',
                'linking error',
                'wasm-opt failed'
            ]
        }
        
        # Configurações de Integração
        self.integration = {
            'dao_bridge_enabled': True,
            'github_api_enabled': True,
            'auto_commit_reports': True,
            'sync_interval': 600  # 10 minutos
        }
        
        # Configurações de Logging
        self.logging = {
            'level': 'INFO',
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            'file': self.project_root / 'sdk_agents.log',
            'max_size': 10 * 1024 * 1024,  # 10MB
            'backup_count': 5
        }
    
    def get_error_files(self) -> Dict[str, Path]:
        """Retorna caminhos dos arquivos de erro."""
        return {
            'all_errors': self.error_tracker_dir / 'all-errors.md',
            'frequent_errors': self.error_tracker_dir / 'frequent-errors.md',
            'resolved_errors': self.error_tracker_dir / 'resolved.md',
            'lessons_learned': self.error_tracker_dir / 'lessons-learned.md',
            'quick_reference': self.error_tracker_dir / 'quick-reference.md'
        }
    
    def get_memory_config(self) -> Dict:
        """Retorna configurações da memória de erros."""
        return {
            'file': self.memory_file,
            'auto_save': True,
            'max_entries': 1000,
            'cleanup_days': 90
        }
    
    def get_github_config(self) -> Dict:
        """Retorna configurações do GitHub."""
        return {
            'repo': 'groovaloo/MMECO',
            'token': os.getenv('GITHUB_TOKEN'),
            'api_base': 'https://api.github.com',
            'timeout': 30
        }
    
    def validate(self) -> List[str]:
        """Valida as configurações e retorna lista de erros."""
        errors = []
        
        # Verificar diretórios
        if not self.blockchain_core.exists():
            errors.append(f"Diretório blockchain-core não encontrado: {self.blockchain_core}")
        
        if not self.error_tracker_dir.exists():
            errors.append(f"Diretório error-tracker não encontrado: {self.error_tracker_dir}")
        
        # Verificar intervalos
        if self.keep_alive['interval_seconds'] < 60:
            errors.append("Intervalo de keep-alive muito curto (< 60s)")
        
        if self.error_monitoring['build_check_interval'] < 60:
            errors.append("Intervalo de monitoramento muito curto (< 60s)")
        
        # Verificar endpoints
        if not self.keep_alive['endpoints']:
            errors.append("Nenhum endpoint de keep-alive configurado")
        
        return errors
    
    def print_config(self):
        """Imprime configurações atuais."""
        print("=== CONFIGURAÇÕES DO SDK ===")
        print(f"Projeto: {self.project_root}")
        print(f"Blockchain Core: {self.blockchain_core}")
        print(f"Error Tracker: {self.error_tracker_dir}")
        print(f"Memory File: {self.memory_file}")
        print()
        
        print("=== KEEP-ALIVE ===")
        print(f"Intervalo: {self.keep_alive['interval_seconds']}s")
        print(f"Endpoints: {len(self.keep_alive['endpoints'])}")
        print(f"Timeout: {self.keep_alive['timeout']}s")
        print(f"Log: {self.keep_alive['log_file']}")
        print()
        
        print("=== MONITORAMENTO DE ERROS ===")
        print(f"Check Interval: {self.error_monitoring['build_check_interval']}s")
        print(f"Auto Import: {self.error_monitoring['auto_import_tracker']}")
        print(f"Generate Reports: {self.error_monitoring['generate_reports']}")
        print()
        
        print("=== ALERTAS ===")
        print(f"Enabled: {self.alerts['enabled']}")
        print(f"Channels: {self.alerts['channels']}")
        print(f"New Error Threshold: {self.alerts['new_error_threshold']}")
        print()


# Instância global de configuração
config = SDKConfig()


def get_config() -> SDKConfig:
    """Retorna a instância global de configuração."""
    return config


def validate_config() -> bool:
    """Valida a configuração e imprime erros se houver."""
    errors = config.validate()
    if errors:
        print("⚠️  Erros de configuração:")
        for error in errors:
            print(f"  - {error}")
        return False
    return True